package ru.madarij.nativeapp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import ru.madarij.nativeapp.data.*
import java.util.Date

@Composable
internal fun HomeScreen(vm: BookViewModel, open: (String, String?) -> Unit, navigate: (String) -> Unit) {
    val chapters by vm.chapters.collectAsStateWithLifecycle()
    val read by vm.read.collectAsStateWithLifecycle()
    val last by vm.last.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val groups = rememberStructure()
    val context = LocalContext.current
    val learning = remember(context) { LearningRepository(context.applicationContext) }
    val attempts by learning.attempts.collectAsStateWithLifecycle(emptyMap())
    LaunchedEffect(learning) { runCatching { learning.load() } }
    val due = attempts.count { it.value.due <= System.currentTimeMillis() }
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ROOT).format(Date())
    val minutes = history.filter { it.date == today }.sumOf { it.seconds } / 60
    val percent = if (chapters.isEmpty()) 0 else read.size * 100 / chapters.size
    val lastTitle = chapters.find { it.id == last?.chapterId }?.let(groups::findTitle)

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                color = MaterialTheme.colorScheme.primaryContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .18f)),
                shadowElevation = 5.dp
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppActionGlyph("contents")
                        Column(Modifier.weight(1f)) {
                            Text("ИБН АЛЬ-КАЙЙИМ · ТОМ 1", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text("Мадаридж ас-саликин", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = .12f))

                    if (lastTitle != null) {
                        Text("Продолжить", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Text(lastTitle, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    } else {
                        Text("Начните с первого раздела и сохраняйте место чтения автоматически.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .8f))
                    }

                    LinearProgressIndicator(
                        progress = { percent / 100f },
                        modifier = Modifier.fillMaxWidth().height(5.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surface.copy(alpha = .7f)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("$percent% · ${read.size} из ${chapters.size} разделов", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .72f))
                        Button(
                            onClick = { (last?.chapterId ?: chapters.firstOrNull()?.id)?.let { open(it, null) } },
                            enabled = chapters.isNotEmpty(),
                            shape = MaterialTheme.shapes.medium,
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                        ) { Text(if (last == null) "Начать" else "Продолжить") }
                    }
                }
            }
        }

        item { Text("Быстрый доступ", style = MaterialTheme.typography.titleMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Содержание", "Главы и темы", "contents", Modifier.weight(1f)) { navigate("contents") }
                HomeAction("Поиск", "По всему тому", "search", Modifier.weight(1f)) { navigate("search") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Изучение", "Проверки и задания", "study", Modifier.weight(1f)) { navigate("study") }
                HomeAction("Словарь", "Термины и контекст", "glossary", Modifier.weight(1f)) { navigate("glossary") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Закладки", "Сохранено · ${bookmarks.size}", "bookmarks", Modifier.weight(1f)) { navigate("bookmarks") }
                HomeAction("Заметки", "Личные записи · ${notes.size}", "notes", Modifier.weight(1f)) { navigate("notes") }
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f)),
                shadowElevation = 2.dp
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${read.size}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                        Text("Прочитано", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    VerticalDivider(Modifier.height(38.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = .35f))
                    Column(Modifier.weight(1f).padding(start = 16.dp)) {
                        Text("$minutes мин", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                        Text("Сегодня", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    VerticalDivider(Modifier.height(38.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = .35f))
                    Column(Modifier.weight(1f).padding(start = 16.dp)) {
                        Text("$due", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                        Text("Повторить", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Text(
                "Рабочий перевод первого тома · редакционная сверка продолжается",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 2.dp, vertical = 4.dp)
            )
        }
        if (chapters.isEmpty()) item { InfoCard("Подготовка книги", status) }
    }
}

@Composable
private fun HomeAction(title: String, subtitle: String, glyph: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier.heightIn(min = 86.dp),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .44f)),
        shadowElevation = 2.dp
    ) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            AppActionGlyph(glyph)
            Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

@Composable
internal fun ContentsScreen(vm: BookViewModel, open: (String, String?) -> Unit, resume: (String) -> Unit) {
    val chapters by vm.chapters.collectAsStateWithLifecycle()
    val read by vm.read.collectAsStateWithLifecycle()
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val last by vm.last.collectAsStateWithLifecycle()
    val positions by vm.positions.collectAsStateWithLifecycle()
    val groups = rememberStructure()
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var savedIndex by rememberSaveable { mutableIntStateOf(0) }
    var savedOffset by rememberSaveable { mutableIntStateOf(0) }
    var restored by remember { mutableStateOf(false) }
    var initialized by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("all") }
    var openedGroups by rememberSaveable { mutableStateOf(listOf<String>()) }
    var openedChapters by rememberSaveable { mutableStateOf(listOf<String>()) }
    var percents by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    val readIds = remember(read) { read.map { it.chapterId }.toSet() }
    val savedIds = remember(bookmarks) { bookmarks.map { it.chapterId }.toSet() }

    LaunchedEffect(positions, read) {
        val result = mutableMapOf<String, Int>()
        positions.forEach { p ->
            val paragraphs = vm.repository.dao.paragraphs(p.chapterId)
            val ordinal = paragraphs.indexOfFirst { it.id == p.paragraphId }
            result[p.chapterId] = if (paragraphs.isEmpty()) 0 else ((ordinal + 1) * 100 / paragraphs.size).coerceIn(0, 99)
        }
        read.forEach { result[it.chapterId] = 100 }
        percents = result
    }
    LaunchedEffect(groups, last?.chapterId) {
        if (groups.isNotEmpty() && !initialized) {
            openedGroups = listOf(groups.find { group -> group.items.any { it.chapterId == last?.chapterId } }?.id ?: groups.first().id)
            if (last != null) openedChapters = listOf(last!!.chapterId)
            initialized = true
        }
        if (groups.isNotEmpty() && !restored) {
            listState.scrollToItem(savedIndex, savedOffset)
            restored = true
        }
    }
    LaunchedEffect(restored) {
        if (restored) snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .collect { (index, offset) -> savedIndex = index; savedOffset = offset }
    }
    fun resetList() { savedIndex = 0; savedOffset = 0; scope.launch { listState.scrollToItem(0) } }

    val fallback = if (groups.isNotEmpty()) groups else listOf(TocGroup("volume1", "Первый том", "editorial_navigation", chapters.map { TocChapter(it.id, it.title, "", emptyList()) }))
    val normalizedQuery = normalizedText(query).text
    val matching = fallback.map { group ->
        group.copy(items = group.items.filter { chapter ->
            (query.isBlank() || normalizedText("${chapter.title} ${chapter.subtitle} ${chapter.topics.joinToString { it.title }}").text.contains(normalizedQuery)) && when (filter) {
                "read" -> chapter.chapterId in readIds
                "saved" -> chapter.chapterId in savedIds
                else -> true
            }
        })
    }.filter { it.items.isNotEmpty() }

    LazyColumn(state = listState, contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        item { Text("Том 1 · ${chapters.size} разделов · ${read.size} прочитано", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        last?.let { position ->
            item {
                Card(onClick = { resume(position.chapterId) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Продолжить с места остановки", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            Text(groups.find { it.items.any { c -> c.chapterId == position.chapterId } }?.items?.find { it.chapterId == position.chapterId }?.title ?: "Последний раздел", style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text("→", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
        item { OutlinedTextField(query, { query = it; resetList() }, label = { Text("Найти главу или тему") }, modifier = Modifier.fillMaxWidth(), singleLine = true, trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = ""; resetList() }) { Text("Очистить") } }) }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("all" to "Все", "read" to "Прочитано", "saved" to "С закладками").forEach { (key, label) ->
                    FilterChip(
                        selected = filter == key,
                        onClick = { filter = key; resetList() },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { openedGroups = matching.map { it.id }; openedChapters = matching.flatMap { it.items }.map { it.chapterId } }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("Раскрыть всё") }
                TextButton(onClick = { openedGroups = emptyList(); openedChapters = emptyList() }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("Свернуть всё") }
            }
        }
        if (matching.isEmpty()) item { InfoCard("Ничего не найдено", "Измените запрос или фильтр.") }
        matching.forEach { group ->
            item(key = "group:${group.id}") {
                val expanded = group.id in openedGroups || query.isNotBlank()
                val count = group.items.count { it.chapterId in readIds }
                Card(onClick = { openedGroups = if (group.id in openedGroups) openedGroups - group.id else openedGroups + group.id }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (expanded) "⌄" else "›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(group.title, style = MaterialTheme.typography.titleSmall)
                            Text("$count из ${group.items.size} прочитано", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (group.id in openedGroups || query.isNotBlank()) group.items.forEach { chapter ->
                item(key = "chapter:${chapter.chapterId}") {
                    val expanded = chapter.chapterId in openedChapters || query.isNotBlank()
                    Card(onClick = { if (chapter.topics.isNotEmpty()) openedChapters = if (chapter.chapterId in openedChapters) openedChapters - chapter.chapterId else openedChapters + chapter.chapterId else open(chapter.chapterId, chapter.entryParagraphId) }, modifier = Modifier.fillMaxWidth().padding(start = 7.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .15f))) {
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(chapter.title, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                TextButton(onClick = { open(chapter.chapterId, chapter.entryParagraphId) }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text(if (chapter.entryParagraphId == null) "Читать" else "К началу") }
                            }
                            chapter.subtitle.replace(" · название для навигации", "").takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            chapter.entryNote?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                            val percent = percents[chapter.chapterId] ?: 0
                            if (percent > 0) {
                                LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth().height(2.dp), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.primary.copy(alpha = .14f))
                                Text(if (percent == 100) "Прочитано" else "Пройдено · $percent%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (chapter.topics.isNotEmpty()) Text("${if (expanded) "⌄" else "›"}  Темы · ${chapter.topics.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                if (chapter.chapterId in openedChapters || query.isNotBlank()) items(chapter.topics, key = { "topic:${chapter.chapterId}:${it.paragraphId}:${it.title}" }) { topic ->
                    Card(onClick = { open(chapter.chapterId, topic.paragraphId) }, modifier = Modifier.fillMaxWidth().padding(start = 20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(horizontal = 13.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(if (topic.provenance == "source_heading") "ТЕМА КНИГИ" else "ТЕМА", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(topic.title, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        item { Text("Следующие тома ещё не включены.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp)) }
    }
}
