import copy
import unittest
from tools.content_gate import validate, digest


def fixture():
    # Synthetic fixture, not a fragment of the book.
    paragraph = {"id": "p1", "order": 0, "ar": "نص تجريبي", "ru": "Тестовый текст.",
                 "role": "author", "status": "reviewed", "source": "fixture:1",
                 "reviewer": "test-only", "reviewed_sha256": digest("نص تجريبي", "Тестовый текст.")}
    return {"edition": {"id": "fixture", "rights_status": "cleared", "rights_evidence": "fixture-only",
                        "source_sha256": ["a" * 64], "structure_verified": True},
            "expected_chapter_ids": ["c1"], "chapters": [
                {"id": "c1", "volume": 1, "order": 0, "title": "Тестовая глава",
                 "source": "fixture:1", "expected_paragraph_ids": ["p1"], "paragraphs": [paragraph]}],
            "questions": []}


class ContentGateTest(unittest.TestCase):
    def test_complete_synthetic_corpus(self):
        self.assertEqual([], validate(fixture()))

    def test_empty_book_cannot_pass(self):
        book = fixture(); book["chapters"] = []; book["expected_chapter_ids"] = []
        self.assertTrue(validate(book))

    def test_missing_chapter(self):
        book = fixture(); book["expected_chapter_ids"].append("c2")
        self.assertTrue(validate(book))

    def test_missing_paragraph(self):
        book = fixture(); book["chapters"][0]["expected_paragraph_ids"].append("p2")
        self.assertTrue(validate(book))

    def test_changed_text_invalidates_review(self):
        book = fixture(); book["chapters"][0]["paragraphs"][0]["ru"] += " Изменение."
        self.assertTrue(validate(book))

    def test_uncleared_rights(self):
        book = fixture(); book["edition"]["rights_status"] = "pending"
        self.assertTrue(validate(book))

    def test_duplicate_id(self):
        book = fixture(); book["chapters"][0]["paragraphs"].append(copy.deepcopy(book["chapters"][0]["paragraphs"][0]))
        self.assertTrue(validate(book))

    def test_corrupted_unicode(self):
        book = fixture(); p = book["chapters"][0]["paragraphs"][0]
        p["ru"] = "Текст\ufffd"; p["reviewed_sha256"] = digest(p["ar"], p["ru"])
        self.assertTrue(validate(book))

    def test_question_requires_real_reviewed_anchor(self):
        book = fixture(); book["questions"] = [{"id": "q1", "paragraph_id": "missing"}]
        self.assertTrue(validate(book))


if __name__ == "__main__":
    unittest.main()
