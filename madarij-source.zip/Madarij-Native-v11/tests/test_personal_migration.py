"""Execute actual migration SQL on host SQLite, not Room Android runtime."""
import json
from pathlib import Path
import re
import sqlite3
import unittest
ROOT = Path(__file__).resolve().parents[1]
class PersonalMigrationTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        schema = json.loads((ROOT / 'app/schemas/ru.madarij.nativeapp.data.BookDatabase/1.json').read_text())['database']
        for entity in schema['entities']:
            self.db.execute(entity['createSql'].replace('${TABLE_NAME}', entity['tableName']))
            for index in entity.get('indices', []): self.db.execute(index['createSql'].replace('${TABLE_NAME}', entity['tableName']))
        for query in schema['setupQueries']: self.db.execute(query)
        self.seed = {
            'bookmarks': [('paragraph:legacy:old-p','legacy','old-p','Моя закладка','Личная запись'),('chapter:legacy','legacy',None,'Глава','')],
            'notes': [('note-old','legacy','old-p','Моя заметка',123456),('note-null','legacy',None,'Общая заметка',123457)],
            'positions': [('legacy','old-p',213,456789)],
            'read_chapters': [('legacy',789123)],
        }
        for table, rows in self.seed.items(): self.db.executemany(f"INSERT INTO {table} VALUES ({','.join('?' for _ in rows[0])})", rows)
        kotlin = (ROOT / 'app/src/main/java/ru/madarij/nativeapp/data/BookDatabase.kt').read_text()
        migration = kotlin.split('val MIGRATION_1_2 =', 1)[1]
        self.sql = re.findall(r'db\.execSQL\("((?:[^"\\]|\\.)*)"\)', migration)
        self.assertTrue(self.sql, 'No executable SQL in actual migration')
        for sql in self.sql: self.db.execute(sql)
    def tearDown(self): self.db.close()
    def test_personal_data_and_old_ids_preserved(self):
        for table, rows in self.seed.items():
            with self.subTest(table=table): self.assertEqual(sorted(rows,key=lambda r:r[0]), self.db.execute(f'SELECT * FROM {table} ORDER BY 1').fetchall())
    def test_history_columns_and_unique_key(self):
        cols = self.db.execute('PRAGMA table_info(reading_history)').fetchall()
        self.assertEqual(['id','date','chapterId','paragraphId','seconds'], [c[1] for c in cols])
        self.assertEqual(['TEXT','TEXT','TEXT','TEXT','INTEGER'], [c[2] for c in cols])
        self.assertTrue(all(c[3] for c in cols))
        self.assertEqual(['id'], [c[1] for c in cols if c[5]])
        row = ('daily:2026-10-05:legacy','2026-10-05','legacy','old-p',60)
        self.db.execute('INSERT INTO reading_history VALUES (?,?,?,?,?)',row)
        with self.assertRaises(sqlite3.IntegrityError): self.db.execute('INSERT INTO reading_history VALUES (?,?,?,?,?)',row)
        self.assertEqual([row],self.db.execute('SELECT * FROM reading_history').fetchall())
    def test_reapplying_sql_preserves_history(self):
        self.db.execute("INSERT INTO reading_history VALUES ('h','2026-10-05','legacy','old-p',30)")
        for sql in self.sql: self.db.execute(sql)
        self.assertEqual(1,self.db.execute('SELECT count(*) FROM reading_history').fetchone()[0])
if __name__ == '__main__': unittest.main()
