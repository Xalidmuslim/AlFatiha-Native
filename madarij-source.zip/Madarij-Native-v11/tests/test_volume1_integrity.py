"""Validate assembled draft assets, without claiming editorial certification."""
import json
from pathlib import Path
import re
import unittest
from collections import Counter
ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets'
def load(path): return json.loads(path.read_text(encoding='utf-8'))
def norm(text): return ' '.join(text.split())
class VolumeIntegrityTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = load(ROOT / 'reference' / 'volume1-literary-reviewed.json')
        cls.corpus = load(ASSETS / 'corpus.json')
        cls.chapters = cls.corpus['chapters']
        cls.paragraphs = [p for c in cls.chapters for p in c['paragraphs']]
        cls.by_id = {p['id']: p for p in cls.paragraphs}
        cls.structure = load(ASSETS / 'structure.json')
        cls.study = load(ASSETS / 'study.json')
    def test_source_ids_order_and_text_preserved(self):
        units = self.source['translation_units']
        self.assertEqual(90, len(self.chapters))
        self.assertEqual(90, len({c['id'] for c in self.chapters}))
        self.assertEqual(self.corpus['expected_chapter_ids'], [c['id'] for c in self.chapters])
        for chapter in self.chapters:
            self.assertEqual(chapter['expected_paragraph_ids'], [p['id'] for p in chapter['paragraphs']])
        self.assertEqual(740, len(self.paragraphs))
        authors = [p for p in self.paragraphs if p['role'] == 'author']
        self.assertEqual(644, len(authors))
        self.assertEqual([u['id'] for u in units], [p['id'] for p in authors])
        self.assertEqual(740, len(self.by_id))
        for unit, paragraph in zip(units, authors):
            with self.subTest(id=unit['id']):
                for language in ('ar', 'ru'):
                    self.assertEqual(unit[language].encode('utf-8'), paragraph[language].encode('utf-8'))
    def test_navigation_sections_and_topic_provenance(self):
        items = [i for g in self.structure['groups'] for i in g['items']]
        self.assertEqual(Counter(c['id'] for c in self.chapters), Counter(i['chapterId'] for i in items))
        chapters = {c['id']: c for c in self.chapters}
        for item in items:
            with self.subTest(section=item['chapterId']):
                self.assertTrue(item['title'].strip())
                self.assertIsNone(re.fullmatch(r'(?:Продолжение(?:\s*\d+)?|Раздел\s+\d+)(?:\s*[·:—].*)?', item['title'], re.I))
                ids = {p['id'] for p in chapters[item['chapterId']]['paragraphs']}
                for topic in item.get('topics', []):
                    self.assertIn(topic['paragraphId'], ids)
                    if topic.get('sourceTitleAr'):
                        self.assertEqual('source_heading', topic['provenance'])
                        self.assertIn(topic['sourceTitleAr'], self.by_id[topic['paragraphId']]['ar'])
    def test_questions_answers_and_source_excerpts(self):
        questions = self.study['questions']
        self.assertEqual(len(questions), len({q['id'] for q in questions}))
        self.assertGreaterEqual(len(questions), 200)
        self.assertTrue({f'q{i:02d}' for i in range(1, 21)}.issubset({q['id'] for q in questions}), 'Retain v1 question IDs for stored attempts')
        for q in questions:
            with self.subTest(id=q['id']):
                self.assertEqual(4, len(q['options']))
                self.assertEqual(1, sum(o['correct'] is True for o in q['options']))
                self.assertEqual(4, len({o['text'] for o in q['options']}))
                self.assertIn(q['sourceParagraphId'], self.by_id)
                excerpt = norm(q['sourceExcerpt'])
                self.assertTrue(excerpt)
                self.assertIn(excerpt, norm(self.by_id[q['sourceParagraphId']]['ru']))
                chapter = next(c for c in self.chapters if c['id'] == q['chapterId'])
                self.assertIn(q['sourceParagraphId'], {p['id'] for p in chapter['paragraphs']})
    def test_each_section_has_questions(self):
        covered = Counter(q['chapterId'] for q in self.study['questions'])
        self.assertEqual([], [c['id'] for c in self.chapters if covered[c['id']] < 1])
    def test_glossary_and_exercise_sources(self):
        terms = self.study['terms']; ids = {t['id'] for t in terms}
        self.assertEqual(len(terms), len(ids))
        for term in terms:
            with self.subTest(term=term['id']):
                self.assertIn(term['sourceParagraphId'], self.by_id)
                for sid in term.get('sourceParagraphIds', []): self.assertIn(sid, self.by_id)
                for related in term.get('relatedTerms', []): self.assertIn(related, ids)
        for exercise in self.study['exercises']:
            self.assertIn(exercise['sourceParagraphId'], self.by_id)
if __name__ == '__main__': unittest.main()
