"""Import volume one into the Android corpus without altering author text.

Reading sections are navigation aids, not a reconstruction of original chapters.
A completed literary review may be carried through as ``literary_reviewed_v1``;
independent theological, hadith/source and rights review remain separate.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path


def sha(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def pages(unit):
    return sorted(set(unit.get('pages', []) + [b['page'] for b in unit.get('source_blocks', [])]))


def heading(unit):
    ar = unit['ar'].replace('\\n', '\n')
    return bool(re.match(r'^\s*(?:فصل|باب|منزلة)(?:\s|$)', ar))


def title(group, index, continuation):
    lo, hi = min(p for u in group for p in pages(u)), max(p for u in group for p in pages(u))
    lines = [s.strip() for s in group[0]['ru'].replace('\\n', '\n').splitlines() if s.strip()]
    if heading(group[0]) and len(lines) > 1 and lines[0] == 'Раздел':
        second = lines[1]
        if len(second) <= 110 and second.startswith('О ') and not second.endswith('.'):
            return second + f' · стр. {lo}–{hi}'
    return (f'Продолжение · стр. {lo}–{hi}' if continuation else f'Раздел {index + 1} · страницы {lo}–{hi}')


def build(source, source_path):
    units = source['translation_units']
    groups, current, continuation = [], [], False
    for unit in units:
        start = bool(current) and heading(unit)
        limit = bool(current) and max(pages(unit)) - min(p for u in current for p in pages(u)) >= 8
        if start or limit:
            groups.append((current, continuation))
            current = []
            continuation = limit and not start
        current.append(unit)
    if current:
        groups.append((current, continuation))

    correction_by_id = {c['unit_id']: c for c in source.get('earlier_editorial_corrections', [])}
    chapters = []
    for index, (group, continued) in enumerate(groups):
        all_pages = sorted(set(p for u in group for p in pages(u)))
        provenance = f"{source['edition_candidate']}; {source['source_url']}; том 1, стр. {all_pages[0]}–{all_pages[-1]}"
        paragraphs = []
        for unit in group:
            p = {k: unit[k] for k in ('id', 'ar', 'ru', 'status')}
            p.update(order=len(paragraphs), role='author', reviewer='', source=provenance,
                     source_pages=pages(unit), independent_review=False,
                     source_sha256=sha(unit['ar']), translation_sha256=sha(unit['ru']))
            for key in ('source_blocks', 'ar_scope'):
                if key in unit:
                    p[key] = unit[key]
            paragraphs.append(p)

            notes = list(unit.get('editorial_notes', []))
            if unit['id'] == 'madarij-v1-p040-draft':
                notes = [n.replace('переведено только имеющееся wording.', 'переведён только сохранившийся фрагмент.') for n in notes]
            correction = correction_by_id.get(unit['id'])
            if correction:
                p['editorial_correction'] = correction
                notes.append(
                    'Примечание переводчика: в цитате 16:53 русский текст передаёт проверенное начало '
                    '«Какое бы благо у вас ни было — оно от Аллаха». Извлечённый арабский текст сохранён '
                    'без изменений; сопоставление с печатным изданием ещё требуется. '
                    'Проверка начала: https://quran.com/an-nahl/53'
                )

            for n, note in enumerate(notes, 1):
                paragraphs.append(dict(
                    id=f"{unit['id']}-editor-note-{n:02d}", order=len(paragraphs),
                    ar='', ru=note, role='editor_note', status='draft_unchecked', reviewer='',
                    source=provenance, source_pages=pages(unit), anchor_paragraph_id=unit['id'],
                    independent_review=False
                ))

        chapters.append(dict(
            id=group[0]['id'] + '-section', volume=1, order=index,
            title=title(group, index, continued), source=provenance, source_pages=all_pages,
            navigation_kind='technical_reading_section', original_chapter_boundary=heading(group[0]),
            expected_paragraph_ids=[p['id'] for p in paragraphs], paragraphs=paragraphs
        ))

    literary_complete = source.get('literary_review', {}).get('status') == 'complete'
    edition = dict(
        id='madarij-2019-volume1-literary-v1' if literary_complete else 'madarij-2019-volume1-draft',
        draft=True, title=source['book'], source_edition=source['edition_candidate'], source_url=source['source_url'],
        rights_status='pending',
        rights_evidence='Авторский арабский текст: общественное достояние. Русский перевод: собственная редакция; независимая проверка прав не проведена.',
        author_text_rights='public_domain', translation_rights='own_draft_not_independently_checked',
        source_sha256=[sha(source_path.read_text(encoding='utf-8'))], structure_verified=False,
        source_edition_completeness_verified=False, translation_independently_verified=False,
        literary_review_status='complete' if literary_complete else 'in_progress',
        literary_reviewed_units=source.get('literary_review', {}).get('reviewed_units', 0),
        publication_ready=False, edition_editorial_apparatus_included=False,
        note=source.get('note', ''),
        navigation_note='Разделы для чтения являются технической разбивкой. Заголовки «Продолжение» и «Раздел N» не являются новыми главами автора.'
    )
    corpus = dict(edition=edition, expected_chapter_ids=[c['id'] for c in chapters], chapters=chapters, questions=[])

    author = [p for c in chapters for p in c['paragraphs'] if p['role'] == 'author']
    assert [(p['id'], p['ar'], p['ru']) for p in author] == [(u['id'], u['ar'], u['ru']) for u in units]
    assert len(set(p['id'] for c in chapters for p in c['paragraphs'])) == sum(len(c['paragraphs']) for c in chapters)
    word_count = sum(len(p['ru'].split()) for p in author)
    status = 'literary_reviewed_v1' if literary_complete else 'draft_unchecked'
    manifest = dict(
        volume=1, draft=True, source_pages=source['source_pages'],
        author_translation_units=len(author), author_ru_words=word_count,
        editor_note_paragraphs=sum(p['role'] == 'editor_note' for c in chapters for p in c['paragraphs']),
        reading_sections=len(chapters), source_file_sha256=edition['source_sha256'][0],
        translation_status=status, literary_review_complete=literary_complete,
        literary_reviewed_units=source.get('literary_review', {}).get('reviewed_units', 0),
        independent_review=False, publication_ready=False, edition_editorial_apparatus_included=False,
        mechanical_checks=dict(author_text_exactly_preserved=True, author_unit_order_preserved=True, ids_unique=True),
        checks_scope=(
            'Arabic-source comparison + literary Russian editing complete; theological/hadith/source verification remains separate.'
            if literary_complete else
            'Mechanical import only; editorial, religious-source and translation review deferred by user.'
        ),
        expected_chapter_ids=corpus['expected_chapter_ids'],
        sections=[dict(
            id=c['id'], source_pages=c['source_pages'], paragraph_count=len(c['paragraphs']),
            author_paragraph_count=sum(p['role'] == 'author' for p in c['paragraphs']),
            expected_paragraph_ids=c['expected_paragraph_ids'], translation_status=status
        ) for c in chapters],
        page_manifest=source['page_manifest'],
        earlier_editorial_corrections=source.get('earlier_editorial_corrections', [])
    )
    return corpus, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--output', type=Path, default=Path('app/src/main/assets/corpus.json'))
    parser.add_argument('--manifest', type=Path, default=Path('app/src/main/assets/content-manifest.json'))
    args = parser.parse_args()
    corpus, manifest = build(json.loads(args.source.read_text(encoding='utf-8')), args.source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(corpus, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    manifest['corpus_sha256'] = hashlib.sha256(args.output.read_bytes()).hexdigest()
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: manifest[k] for k in ('author_translation_units', 'author_ru_words', 'editor_note_paragraphs', 'reading_sections', 'translation_status')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
