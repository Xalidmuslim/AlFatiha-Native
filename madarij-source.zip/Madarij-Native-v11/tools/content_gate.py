"""Read-only corpus audit. Never repairs or silently truncates source text."""
import argparse
import hashlib
import json
import re
from pathlib import Path


def digest(ar, ru):
    return hashlib.sha256((ar + "\0" + ru).encode("utf-8")).hexdigest()


def validate(book):
    errors = []
    edition = book.get("edition", {})
    if edition.get("rights_status") != "cleared" or not edition.get("rights_evidence"):
        errors.append("edition: rights not documented")
    if edition.get("structure_verified") is not True:
        errors.append("edition: independent structure not verified")
    hashes = edition.get("source_sha256", [])
    if not hashes or any(not re.fullmatch(r"[a-f0-9]{64}", h) for h in hashes):
        errors.append("edition: missing source SHA-256")
    chapters = book.get("chapters", [])
    if not chapters:
        errors.append("book: empty corpus")
    expected = book.get("expected_chapter_ids", [])
    if not expected or [c.get("id") for c in chapters] != expected:
        errors.append("book: chapter order/completeness mismatch")
    ids, paragraphs = set(), {}

    def register(identifier):
        if not isinstance(identifier, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]+", identifier):
            errors.append(f"invalid stable id: {identifier!r}")
        if identifier in ids:
            errors.append(f"duplicate id: {identifier}")
        ids.add(identifier)

    last_volume = 0
    for index, chapter in enumerate(chapters):
        cid = chapter.get("id")
        register(cid)
        volume = chapter.get("volume", 0)
        if not isinstance(volume, int) or volume < 1 or volume < last_volume:
            errors.append(f"{cid}: invalid volume order")
        else:
            last_volume = volume
        if chapter.get("order") != index:
            errors.append(f"{cid}: invalid chapter order")
        if not chapter.get("title", "").strip() or not chapter.get("source"):
            errors.append(f"{cid}: missing title/source")
        blocks = chapter.get("paragraphs", [])
        if not blocks:
            errors.append(f"{cid}: empty chapter")
        if not chapter.get("expected_paragraph_ids") or [p.get("id") for p in blocks] != chapter.get("expected_paragraph_ids"):
            errors.append(f"{cid}: paragraph order/completeness mismatch")
        for position, p in enumerate(blocks):
            pid = p.get("id")
            register(pid)
            paragraphs[pid] = p
            if p.get("order") != position:
                errors.append(f"{pid}: invalid paragraph order")
            if p.get("role") not in {"author", "edition_note", "editor_note", "quran", "hadith"}:
                errors.append(f"{pid}: unspecified text role")
            if p.get("status") != "reviewed" or not p.get("reviewer") or not p.get("source"):
                errors.append(f"{pid}: unreviewed/source missing")
            ar, ru = p.get("ar", ""), p.get("ru", "")
            if not ar.strip() or not ru.strip():
                errors.append(f"{pid}: empty original/translation")
            if p.get("reviewed_sha256") != digest(ar, ru):
                errors.append(f"{pid}: changed since review")
            for language, value in (("ar", ar), ("ru", ru)):
                if "\ufffd" in value or re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", value):
                    errors.append(f"{pid}/{language}: damaged Unicode")
                if re.search(r"<\s*/?\s*[A-Za-z][^>]*>|```|\*\*|\[.+?\]\(.+?\)", value):
                    errors.append(f"{pid}/{language}: markup in plain text")
                if re.search(r" {2,}", value):
                    errors.append(f"{pid}/{language}: repeated spaces")
                if any(ch in value for ch in "\u202a\u202b\u202c\u202d\u202e"):
                    errors.append(f"{pid}/{language}: embedded bidi override")
            if p.get("role") in {"quran", "hadith"} and not p.get("reference"):
                errors.append(f"{pid}: citation missing")
    for q in book.get("questions", []):
        register(q.get("id"))
        if q.get("paragraph_id") not in paragraphs:
            errors.append(f"{q.get('id')}: unknown question anchor")
        options = q.get("options", [])
        if len(options) != 4 or len({o.get("id") for o in options}) != 4:
            errors.append(f"{q.get('id')}: four unique answer IDs required")
        if sum(o.get("correct") is True for o in options) != 1:
            errors.append(f"{q.get('id')}: one correct answer required")
        if any(not o.get("text") or not o.get("explanation") for o in options):
            errors.append(f"{q.get('id')}: missing answer/explanation")
        if q.get("status") != "reviewed" or not q.get("reviewer"):
            errors.append(f"{q.get('id')}: question unreviewed")
    return errors


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("corpus", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    errors = validate(json.loads(args.corpus.read_text(encoding="utf-8")))
    report = {"release_allowed": not errors, "errors": errors,
              "corpus_sha256": hashlib.sha256(args.corpus.read_bytes()).hexdigest(),
              "limits": "Automated structural checks do not establish translation accuracy or legal clearance."}
    if args.report:
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
