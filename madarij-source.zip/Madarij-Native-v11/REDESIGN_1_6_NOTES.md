# 1.6 polish

- Fixed status bar insets globally.
- Reader now owns a compact safe-area header: Back / title / Aa / menu.
- Removed duplicate reader header metadata and tightened vertical rhythm.
- Removed purple fallback accents by defining secondary containers and explicit progress/filter colors.
- Removed user-visible "название для навигации" technical wording.
- Compact Contents and Home cards.
- Added extra list bottom padding and kept reading/navigation state logic unchanged.
