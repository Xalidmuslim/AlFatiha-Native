package ru.madarij.nativeapp

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BookApp() }
    }
}

internal fun readerRoute(id:String,paragraph:String?=null,query:String="") =
    "read/${Uri.encode(id)}?paragraph=${Uri.encode(paragraph.orEmpty())}&query=${Uri.encode(query)}"

@Composable
fun BookApp(vm:BookViewModel=viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val chapters by vm.chapters.collectAsStateWithLifecycle()
    val dark = settings.theme == "dark" || settings.theme == "system" && isSystemInDarkTheme()
    val colors = when {
        dark -> darkColorScheme(
            primary = Color(0xFF8FB8A5), onPrimary = Color(0xFF17372B),
            primaryContainer = Color(0xFF30473D), onPrimaryContainer = Color(0xFFD9E9E1),
            secondary = Color(0xFFC5AB87), onSecondary = Color(0xFF342A20),
            secondaryContainer = Color(0xFF30473D), onSecondaryContainer = Color(0xFFD9E9E1),
            background = Color(0xFF151917), onBackground = Color(0xFFE7EAE6),
            surface = Color(0xFF1E2421), onSurface = Color(0xFFE7EAE6),
            surfaceVariant = Color(0xFF29312D), onSurfaceVariant = Color(0xFFB8C2BC),
            outline = Color(0xFF526159)
        )
        settings.theme == "sepia" -> lightColorScheme(
            primary = Color(0xFF4D6E5C), onPrimary = Color.White,
            primaryContainer = Color(0xFFE3E7D8), onPrimaryContainer = Color(0xFF26392F),
            secondary = Color(0xFF8A6D49), onSecondary = Color.White,
            secondaryContainer = Color(0xFFE3E7D8), onSecondaryContainer = Color(0xFF26392F),
            background = Color(0xFFF2E8D5), onBackground = Color(0xFF312B23),
            surface = Color(0xFFF8F0E2), onSurface = Color(0xFF312B23),
            surfaceVariant = Color(0xFFE8DCC8), onSurfaceVariant = Color(0xFF665B4C),
            outline = Color(0xFFA99A85)
        )
        else -> lightColorScheme(
            primary = Color(0xFF356D57), onPrimary = Color.White,
            primaryContainer = Color(0xFFE2ECE5), onPrimaryContainer = Color(0xFF1F4033),
            secondary = Color(0xFF8B6D4E), onSecondary = Color.White,
            secondaryContainer = Color(0xFFE2ECE5), onSecondaryContainer = Color(0xFF1F4033),
            background = Color(0xFFF6F2EA), onBackground = Color(0xFF27302B),
            surface = Color(0xFFFCFAF5), onSurface = Color(0xFF27302B),
            surfaceVariant = Color(0xFFEDE7DD), onSurfaceVariant = Color(0xFF666B67),
            outline = Color(0xFFD0C8BC)
        )
    }

    MaterialTheme(
        colorScheme = colors,
        typography = MadarijTypography,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(10.dp),
            small = RoundedCornerShape(AppRadius.small),
            medium = RoundedCornerShape(AppRadius.medium),
            large = RoundedCornerShape(AppRadius.large),
            extraLarge = RoundedCornerShape(AppRadius.hero)
        )
    ) {
        val nav = rememberNavController()
        var readerForward by remember { mutableStateOf(true) }
        val entry by nav.currentBackStackEntryAsState()
        val route = entry?.destination?.route.orEmpty()
        val isReader = route.startsWith("read/")
        val scope = rememberCoroutineScope()
        val context = LocalContext.current

        SideEffect {
            (context as? Activity)?.window?.let { window ->
                val attr = window.attributes
                attr.screenBrightness = if (isReader || route == "settings") settings.brightness else -1f
                window.attributes = attr
            }
        }

        val title = when {
            route == "contents" -> "Содержание"
            route == "search" -> "Поиск"
            route == "bookmarks" -> "Закладки"
            route == "notes" -> "Мои заметки"
            route == "settings" -> "Настройки чтения"
            route == "about" -> "О книге"
            route == "progress" -> "Прогресс"
            route == "glossary" -> "Словарь"
            route == "more" -> "Ещё"
            route == "backup" -> "Резервная копия"
            route.startsWith("study") -> "Изучение"
            isReader -> "Степени идущих"
            else -> "Степени идущих"
        }
        val subtitle = when {
            route == "home" -> null
            route == "contents" -> "Главы, темы и место чтения"
            route == "search" -> "По всему первому тому"
            route == "bookmarks" -> "Сохранённые места"
            route == "notes" -> "Личные записи"
            route == "settings" -> "Текст, тема и чтение"
            route == "progress" -> "Чтение и усвоение"
            route == "glossary" -> "Термины и контекст"
            route.startsWith("study") -> "Проверки, задания и повторение"
            isReader -> "Том 1"
            else -> null
        }
        val tabs = listOf("home" to "Главная", "contents" to "Содержание", "study" to "Изучение", "more" to "Ещё")
        val selectedTab = selectedMainTab(route)
        val primaryBack = primaryBackAction(route)

        BackHandler(enabled = primaryBack != PrimaryBackAction.POP) {
            if (primaryBack == PrimaryBackAction.HOME && !nav.popBackStack("home", false)) {
                nav.navigate("home") { launchSingleTop = true }
            }
        }

        val tabRoot = route in setOf("home","contents","bookmarks","notes","progress","glossary","settings","about","backup","more","search") || route.startsWith("study")
        val openReader:(String,String?,String)->Unit = { chapter,p,q -> nav.navigate(readerRoute(chapter,p,q)) }
        val openFromContents:(String,String?)->Unit = { chapter,paragraph -> scope.launch {
            val target = paragraph?.let { vm.repository.dao.paragraph(it) }
                ?: vm.repository.dao.firstParagraphId(chapter)?.let { vm.repository.dao.paragraph(it) }
            target?.let { nav.navigate(readerRoute(it.chapterId,it.id)) }
        }}
        val openSource:(String)->Unit = { id -> scope.launch {
            vm.repository.dao.paragraph(id)?.let { nav.navigate(readerRoute(it.chapterId,it.id)) }
        }}
        val navigate:(String)->Unit = { nav.navigate(it) { launchSingleTop = true } }
        val reduceMotion = settings.reducedMotion || !android.animation.ValueAnimator.areAnimatorsEnabled()

        Scaffold(
            containerColor = colors.background,
            topBar = {
                if (!isReader) MadarijTopBar(
                    title = title,
                    subtitle = subtitle,
                    canBack = !tabRoot,
                    onBack = { nav.popBackStack() },
                    showSearch = !isReader && route != "search",
                    onSearch = { navigate("search") },
                    showTextSettings = !isReader && route != "settings" && route != "search",
                    onTextSettings = { navigate("settings") }
                )
            },
            bottomBar = {
                Column(Modifier.navigationBarsPadding()) {
                    MadarijBottomBar(tabs, selectedTab) { destination ->
                        when {
                            destination == "home" -> nav.navigate("home") {
                                popUpTo(nav.graph.startDestinationId) { inclusive=false; saveState=false }
                                launchSingleTop=true; restoreState=false
                            }
                            destination == "contents" && shouldOpenContentsRoot(route) -> {
                                if(!nav.popBackStack("contents",false)) nav.navigate("contents") {
                                    popUpTo(nav.graph.startDestinationId) { inclusive=false; saveState=false }
                                    launchSingleTop=true; restoreState=false
                                }
                            }
                            destination == "contents" -> Unit
                            else -> nav.navigate(destination) {
                                popUpTo(nav.graph.startDestinationId) { saveState=true }
                                launchSingleTop=true; restoreState=true
                            }
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = "home",
                modifier = Modifier.padding(padding),
                enterTransition = {
                    if (reduceMotion) EnterTransition.None
                    else {
                        val readerToReader = initialState.destination.route?.startsWith("read/") == true && targetState.destination.route?.startsWith("read/") == true
                        if (readerToReader) {
                            fadeIn(tween(180, easing = FastOutSlowInEasing)) +
                                slideInHorizontally(tween(270, easing = FastOutSlowInEasing)) { if (readerForward) it else -it }
                        } else {
                            fadeIn(tween(230, easing = FastOutSlowInEasing)) +
                                slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { it / 12 } +
                                scaleIn(tween(280, easing = FastOutSlowInEasing), initialScale = .992f)
                        }
                    }
                },
                exitTransition = {
                    if (reduceMotion) ExitTransition.None
                    else {
                        val readerToReader = initialState.destination.route?.startsWith("read/") == true && targetState.destination.route?.startsWith("read/") == true
                        if (readerToReader) {
                            fadeOut(tween(130, easing = FastOutSlowInEasing)) +
                                slideOutHorizontally(tween(245, easing = FastOutSlowInEasing)) { if (readerForward) -it else it }
                        } else {
                            fadeOut(tween(190, easing = FastOutSlowInEasing)) +
                                slideOutHorizontally(tween(230, easing = FastOutSlowInEasing)) { -it / 18 } +
                                scaleOut(tween(230, easing = FastOutSlowInEasing), targetScale = .996f)
                        }
                    }
                },
                popEnterTransition = {
                    if (reduceMotion) EnterTransition.None
                    else fadeIn(tween(230, easing = FastOutSlowInEasing)) +
                        slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { -it / 12 } +
                        scaleIn(tween(280, easing = FastOutSlowInEasing), initialScale = .992f)
                },
                popExitTransition = {
                    if (reduceMotion) ExitTransition.None
                    else fadeOut(tween(190, easing = FastOutSlowInEasing)) +
                        slideOutHorizontally(tween(230, easing = FastOutSlowInEasing)) { it / 18 } +
                        scaleOut(tween(230, easing = FastOutSlowInEasing), targetScale = .996f)
                }
            ) {
                composable("home") { HomeScreen(vm,{id,p -> openReader(id,p,"")},navigate) }
                composable("contents") { ContentsScreen(vm,openFromContents) { chapter -> openReader(chapter,null,"") } }
                composable("search") { SearchScreen(vm,openReader) }
                composable("bookmarks") { BookmarksScreen(vm) {id,p -> openReader(id,p,"")} }
                composable("notes") { NotesScreen(vm) {id,p -> openReader(id,p,"")} }
                composable("progress") { ProgressScreen(vm,{id,p -> openReader(id,p,"")},navigate) }
                composable("more") { MoreScreen(navigate) }
                composable("settings") { SettingsPanel(settings,vm::settings) }
                composable("about") { AboutScreen() }
                composable("backup") { BackupScreen(vm) }
                composable("glossary") { GlossaryScreen(openSource) }
                composable(
                    "study?chapter={chapter}&review={review}",
                    arguments=listOf(
                        navArgument("chapter") { type=NavType.StringType; defaultValue="" },
                        navArgument("review") { type=NavType.BoolType; defaultValue=false }
                    )
                ) { e ->
                    StudyScreen(
                        vm, openSource,
                        initialChapterId=e.arguments?.getString("chapter")?.takeIf {it.isNotEmpty()},
                        initialTab=if(e.arguments?.getBoolean("review")==true) 3 else if(!e.arguments?.getString("chapter").isNullOrEmpty()) 1 else 0
                    )
                }
                composable(
                    "read/{id}?paragraph={paragraph}&query={query}",
                    arguments=listOf(
                        navArgument("paragraph") {type=NavType.StringType;defaultValue=""},
                        navArgument("query") {type=NavType.StringType;defaultValue=""}
                    )
                ) { e ->
                    val chapter=chapters.find {it.id==e.arguments?.getString("id")}
                    if(chapter==null) InfoCard("Подготовка книги","Раздел загружается…")
                    else Reader(
                        vm, chapter, settings,
                        e.arguments?.getString("paragraph")?.takeIf {it.isNotEmpty()},
                        e.arguments?.getString("query").orEmpty(),
                        onStudy={navigate("study?chapter=${Uri.encode(it)}")},
                        onOpenParagraph=openSource,
                        onBack={ nav.popBackStack() },
                        navigate={ id ->
                            val fromIndex = chapters.indexOfFirst { it.id == chapter.id }
                            val toIndex = chapters.indexOfFirst { it.id == id }
                            if (fromIndex >= 0 && toIndex >= 0) readerForward = toIndex >= fromIndex
                            nav.navigate(readerRoute(id)) { popUpTo(e.destination.id) { inclusive=true } }
                        }
                    )
                }
            }
        }
    }
}
