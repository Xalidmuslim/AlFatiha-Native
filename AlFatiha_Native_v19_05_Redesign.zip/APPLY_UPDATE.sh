#!/usr/bin/env bash
set -e
rm -f AlFatiha_Native_v19_05_Redesign.zip
rm -f APPLY_UPDATE.sh
git add -A
if git diff --cached --quiet; then
  echo 'Нет новых изменений для коммита.'
else
  git commit -m 'Native UI redesign based on 19.05'
  git push
fi
echo 'Готово. GitHub Actions автоматически запустит сборку APK.'
